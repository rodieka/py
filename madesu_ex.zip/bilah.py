def separate_passwords(input_file, output_file):
    try:
        with open(input_file, 'r', encoding='utf-8') as file:
            passwords = file.read().splitlines()
        
        with open(output_file, 'w', encoding='utf-8') as file:
            for password in passwords:
                file.write(password + '\n')
        print("Passwords separated successfully.")
    except Exception as e:
        print(f"Error: {e}")

# Gunakan fungsi di atas dengan memberikan nama file input dan output seperti contoh di bawah ini:
separate_passwords('files/password.txt', 'files/passwords.txt')
