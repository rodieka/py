import requests,sys
from iprange import centos_panel

def main():
    x = input(": ")
    centos_panel.main(x)

main()