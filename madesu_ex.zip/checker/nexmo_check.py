import vonage
from tool._print import nexmo_print

def main(key,sec,dari):
    try:
        client = vonage.Client(key=key, sret=sec)
        result = client.get_balance()
        open("result/nexmo.txt", "a").write(f"{key}|{sec}|{dari} Balance: {result['value']:0.2f} EUR\n")
        return nexmo_print(key,sec,result)
    except:
        pass