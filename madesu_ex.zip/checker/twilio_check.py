from twilio.rest import Client
from tool._print import twilo_print

def check_twilio_balance(account_sid,auth_token):
    try:
        client = Client(account_sid, auth_token)
        account = client.api.accounts(account_sid).fetch()
        balance = account.balance
        with open("result/twilio.txt","a") as wr:
            wr.write(f"{account_sid}:{auth_token} | {balance.balance}")
        return twilo_print(balance)
    except Exception:
        pass