import requests,json
from twilio.rest import Client

def get_balance(a,t):
    r = requests.get('https://api.twilio.com/2010-04-01/Accounts/'+a+'/Balance.json', auth=(a,t))
    Json = json.dumps(r.json())
    resp = json.loads(Json)
    balance = resp ['balance']
    currency = resp ['currency']
    return str(balance)+' '+str(currency)

def get_phone(a,t):
    client = Client(a,t)
    incoming_phone_numbers = client.incoming_phone_numbers.list(limit=20)
    for record in incoming_phone_numbers:
        return record.phone_number

def get_type(a,t):
    client = Client(a,t)
    account = client.api.accounts.create()  
    return account.type

def send_sms(a,t,bod,phone,tos):
    try:
        client = Client(a,t)
        message = client.messages.create(
                                    body=str(bod),
                                    from_= phone,
                                    to=tos
                                )
        return message.status
    except:
        return 'die' 