import requests,re
from iprange import jembot

jembotngw2 = jembot.jembotngw2

binglist = {"http://www.bing.com/search?q=&count=50&first=1",
"http://www.bing.com/search?q=&count=50&first=51",
"http://www.bing.com/search?q=&count=50&first=101",
"http://www.bing.com/search?q=&count=50&first=151",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.com/search?q=&count=50&first=251",
"http://www.bing.com/search?q=&count=50&first=301",
"http://www.bing.com/search?q=&count=50&first=351",
"http://www.bing.com/search?q=&count=50&first=401",
"http://www.bing.com/search?q=&count=50&first=451",
"http://www.bing.com/search?q=&count=50&first=501",
"http://www.bing.com/search?q=&count=50&first=551",
"http://www.bing.com/search?q=&count=50&first=601",
"http://www.bing.com/search?q=&count=50&first=651",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.vn/search?q=&count=50&first=101"}

def dorkscan(dork):
  jembotngw2(dork)
  if "ip" not in dork:
    dork = " ip:\""+dork+"\" "
  print("START REVERSE FROM IP => "+dork)
  for bing in binglist:
    bingg = bing.replace("&count",dork+"&count")
    try:
      r = requests.get(bingg)
      checktext = r.text
      checktext = checktext.replace("<strong>","")
      checktext = checktext.replace("</strong>","")
      checktext = checktext.replace('<span dir="ltr">','')
      checksites = re.findall('<cite>(.*?)</cite>',checktext)
      for sites in checksites:
        sites = sites.replace("http://","protocol1")
        sites = sites.replace("https://","protocol2")
        sites = sites + "/"
        site = sites[:sites.find("/")+0]
        site = site.replace("protocol1","http://")
        site = site.replace("protocol2","https://")
        try:
          jembotngw2(site)
        except:
            pass
    except:
      pass