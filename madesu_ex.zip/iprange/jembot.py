from iprange import di_check


def jembotngw2(sites):
    if 'http' not in sites:
        site = 'http://'+sites
        di_check.di_chckngntd(site)
    else:
        di_check.di_chckngntd(sites)