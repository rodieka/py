import requests
from tool import cpanel

def redirected_url(i,username,password):
    try:
        response = requests.get("http://"+i+":2083", allow_redirects=False)
        if response.status_code in (301, 302, 303, 307, 308):
            redirected_url = response.headers['Location']
            cpanel.main(url=redirected_url,username=username,password=password)
    except:
        pass