merah = '\x1b[31m'
hijau = '\x1b[32m'
kuning = '\x1b[33m'
biru = '\x1b[34m'
ungu = '\x1b[35m'
langit = '\x1b[36m'
putih = '\x1b[37m'

def nexmo_print(result):
    print(f"{hijau}[Nexmo] {putih}Balance : {langit}{result['value']:0.2f} EUR")

def twilo_print(balance):
    print(f"{hijau}[Twilio] {putih}Balance : {langit}{balance.currency} {balance.balance}")

def smtp_print():
    print(f'{hijau}[SMTP] {putih}Sent To Your :{langit}Email')

def aws_print(key,sec,reg,limit,listemail):
    print(key+"|"+sec+"|"+reg + "|" +  limit +"|" + listemail)

def sendgrid_print():
    print(f'{hijau}[Sendgrid] {putih}Sent To Your :{langit}Email')

def print_vuln(cms,poc,site):
    print (f'{hijau}[{poc}][{cms}] : {langit}{site}')

def not_vuln(cms,poc,site):
    print (f'{merah}[{poc}][{cms}] : {langit}{site}')

def print_shell(cms,poc,site):
    print (f'{ungu}[{poc}][{cms}] : {langit}{site}')

def bad_site(site,cms):
    print (f'{merah}[{cms}] : {langit}{site}')

def print_centos(site,cms):
    print (f'{ungu}[{cms}] : {langit}{site}')
    